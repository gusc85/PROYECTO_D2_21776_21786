/*
 * File:   main.c
 * Author: Pablo
 * Ejemplo de uso de I2C Master
 * Created on 17 de febrero de 2020, 10:32 AM
 */
//*****************************************************************************
// Palabra de configuraci�n
//*****************************************************************************
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <stdint.h>
#include <stdio.h>
//#include <pic16f887.h>
#include "I2C.h"
#include <xc.h>
#include "LCD.h"
//*****************************************************************************
// Definici�n de variables
//*****************************************************************************
#define _XTAL_FREQ 8000000
 ///////////////////////////// sensor 1 /////////////////////////////////
        uint8_t contador = 0;
        uint8_t objeto_detectado = 0;  // Variable para rastrear si se ha detectado un objeto
        ///////////////////////////// sensor 2 /////////////////////////////////
        uint8_t contador2 = 0;
        uint8_t objeto_detectado2 = 0;  // Variable para rastrear si se ha detectado un objeto
//*****************************************************************************
// Definici�n de funciones para que se puedan colocar despu�s del main de lo 
// contrario hay que colocarlos todas las funciones antes del main
//*****************************************************************************
void setup(void);

//*****************************************************************************
// Main
//*****************************************************************************
void main(void) {
    setup();
   char buffer[20]; // Aumentamos el tama�o del buffer para manejar las cadenas formateadas
    
    while(1){
        I2C_Master_Start();
        I2C_Master_Write(0x50);
        //I2C_Master_Write(PORTB);
        I2C_Master_Stop();
        __delay_ms(200);
       
        I2C_Master_Start();
        I2C_Master_Write(0x51);
        PORTB = I2C_Master_Read(0);
        I2C_Master_Stop();
        __delay_ms(200);
        


        
       
      
   
        if (RB3 == 1) {  // Si el sensor detecta un objeto
            if (!objeto_detectado) {  // Verifica si a�n no se ha detectado un objeto
                contador++;  // Incrementa el contador solo si no se ha detectado un objeto previamente
                objeto_detectado = 1;  // Marca que se ha detectado un objeto
                __delay_ms(100);  // Espera un tiempo para evitar contar m�ltiples veces por un solo objeto
            }
        } else {
            objeto_detectado = 0;  // Restablece la marca de detecci�n cuando no se detecta ning�n objeto
        }
        
        if (RB2 == 1) {  // Si el sensor detecta un objeto
            if (!objeto_detectado2) {  // Verifica si a�n no se ha detectado un objeto
                contador2++;  // Incrementa el contador solo si no se ha detectado un objeto previamente
                objeto_detectado2 = 1;  // Marca que se ha detectado un objeto
                __delay_ms(100);  // Espera un tiempo para evitar contar m�ltiples veces por un solo objeto
            }
        } else {
            objeto_detectado2 = 0;  // Restablece la marca de detecci�n cuando no se detecta ning�n objeto
        }

         float resultado = contador + (contador2 * 0.5);
         
         
         
         // Convertir los valores a cadenas y mostrarlos en el LCD
        Lcd_Clear(); // Borra la pantalla antes de escribir nuevos datos
        Lcd_Set_Cursor(1, 1); // Establece el cursor en la primera l�nea, primera posici�n
        sprintf(buffer, "Q1: %d", contador);
        Lcd_Write_String(buffer);
        
        Lcd_Set_Cursor(1, 8); // Establece el cursor en la segunda l�nea, primera posici�n
        sprintf(buffer, "Q0.5: %d", contador2);
        Lcd_Write_String(buffer);
        
        Lcd_Set_Cursor(2, 1); // Establece el cursor en la segunda l�nea, d�cima posici�n
        sprintf(buffer, "Tot:%.2f", resultado); // Muestra resultado con dos decimales
        Lcd_Write_String(buffer);
        
        
         if (TRISBbits.TRISB5 == 1) {
            RB5 = 1; // Encender el LED en el maestro
        } else {
            RB5 = 0; // Apagar el LED en el maestro
        }
        if (RB5 == 1) {  // Si el sensor detecta un objeto
  
                Lcd_Set_Cursor(2, 10); // Establece el cursor en la segunda l�nea, d�cima posici�n
                Lcd_Write_String("MDC ON");
            }
        else {
            Lcd_Set_Cursor(2, 10); // Establece el cursor en la segunda l�nea, d�cima posici�n
                Lcd_Write_String("MDC OFF");
        }
        
       // __delay_ms(1000); // Espera un tiempo antes de actualizar la pantalla (ajusta seg�n sea necesario)
    }
    return;
     
   
    
    
    /////////////////////////////////////////////////////////////////////////////////
      /* // Slave 2
        I2C_Master_Start();
        I2C_Master_Write(0x51);
       // PORTA = I2C_Master_Read(0);
        I2C_Master_Stop();
        __delay_ms(200);
       * */
        
    }
   

//*****************************************************************************
// Funci�n de Inicializaci�n
//*****************************************************************************
void setup(void){
     ANSEL = 0;
     
     TRISA = 0;
     //TRISB = 0b11111111;
     TRISC = 0b11111111;
     TRISD = 0b00000000;
     TRISBbits.TRISB2 = 1 ;
     TRISBbits.TRISB3 = 1 ;
   
     
     //PORTA = 0;
     PORTB = 0;
     PORTC = 1;
     PORTD = 0;
   
    
     I2C_Master_Init(100000);        // Inicializar Comuncaci�n I2C
     ANSELH &= 0xFC; // Configura RE0 y RE1 como entradas digitales
     TRISE &= 0xFC;  // Configura RE0 y RE1 como salidas digitales

     Lcd_Init();

     return;
}