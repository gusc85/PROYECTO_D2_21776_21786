/*
 * File:   main.c
 * Author: Pablo
 * Ejemplo de uso de I2C Esclavo
 * Created on 17 de febrero de 2020, 10:32 AM
 */
//*****************************************************************************
// Palabra de configuraci�n
//*****************************************************************************
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <stdint.h>
//#include <pic16f887.h>
#include "I2C.h"
#include <xc.h>
//*****************************************************************************
// Definici�n de variables
//*****************************************************************************
// Configuraci�n de los registros ADC
__CONFIG(FOSC_HS & WDTE_OFF & PWRTE_OFF & MCLRE_OFF & CP_OFF & CPD_OFF & BOREN_OFF & IESO_OFF & FCMEN_OFF & LVP_OFF & BOR4V_BOR40V & WRT_OFF);

#define _XTAL_FREQ 8000000 // Frecuencia de oscilador, ajusta esto a tu configuraci�n

// Definiciones de pines

uint8_t z;
uint8_t dato;
//*****************************************************************************
// Definici�n de funciones para que se puedan colocar despu�s del main de lo 
// contrario hay que colocarlos todas las funciones antes del main
//*****************************************************************************
void setup(void);
//*****************************************************************************
// C�digo de Interrupci�n 
//*****************************************************************************
void __interrupt() isr(void){
   if(PIR1bits.SSPIF == 1){ 

        SSPCONbits.CKP = 0;
       
        if ((SSPCONbits.SSPOV) || (SSPCONbits.WCOL)){
            z = SSPBUF;                 // Read the previous value to clear the buffer
            SSPCONbits.SSPOV = 0;       // Clear the overflow flag
            SSPCONbits.WCOL = 0;        // Clear the collision bit
            SSPCONbits.CKP = 1;         // Enables SCL (Clock)
        }

        if(!SSPSTATbits.D_nA && !SSPSTATbits.R_nW) {
            //__delay_us(7);
            z = SSPBUF;                 // Lectura del SSBUF para limpiar el buffer y la bandera BF
            //__delay_us(2);
            PIR1bits.SSPIF = 0;         // Limpia bandera de interrupci�n recepci�n/transmisi�n SSP
            SSPCONbits.CKP = 1;         // Habilita entrada de pulsos de reloj SCL
            while(!SSPSTATbits.BF);     // Esperar a que la recepci�n se complete
            PORTC = SSPBUF;             // Guardar en el PORTD el valor del buffer de recepci�n
            __delay_us(250);
            
        }else if(!SSPSTATbits.D_nA && SSPSTATbits.R_nW){
            z = SSPBUF;
            BF = 0;
            SSPBUF = PORTB;
            SSPCONbits.CKP = 1;
            __delay_us(250);
            while(SSPSTATbits.BF);
        }
       
        PIR1bits.SSPIF = 0;    
    }
}

//*****************************************************************************
// Main
//*****************************************************************************
    
    #define LDR_PIN   AN0  // Pin del sensor LDR (entrada anal�gica)
#define MOTOR_PIN RB0  // Pin de control del motor DC

void main() {
    TRISB0 = 0; // Configurar el pin del motor como salida
    MOTOR_PIN = 0; // Apagar el motor inicialmente

    // Configurar el pin del sensor LDR como entrada anal�gica
    TRISA0 = 1;

    // Configurar el m�dulo ADC
    ADCON0 = 0x01; // Seleccionar AN0 como entrada anal�gica
    ADCON1 = 0x80; // Configurar el reloj de conversi�n a Fosc/2
    //ADCON2 = 0x88; // Resultado justificado a la derecha, Tad = 2Tosc

    while (1) {
        // Realizar una conversi�n ADC
        GO_nDONE = 1; // Iniciar la conversi�n

        while (GO_nDONE); // Esperar a que la conversi�n termine

        // Leer el valor ADC
        unsigned int adcValue = ((unsigned int)ADRESH << 8) | ADRESL;

        // Si la luz es baja (valor ADC alto), encender el motor
        if (adcValue > 512) { // Ajusta este umbral seg�n tu sensor LDR
            MOTOR_PIN = 1; // Encender el motor
           
        } else {
            MOTOR_PIN = 0; // Apagar el motor si la luz es alta
            
        }
    }
}
    

void setup(void){
I2C_Slave_Init(0x50);  
   
}