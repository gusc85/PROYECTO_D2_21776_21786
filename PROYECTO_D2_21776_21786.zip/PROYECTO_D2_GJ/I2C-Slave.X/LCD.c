/*
 * File:   LCD.c
 * Author: julio
 *
 * Created on 1 de septiembre de 2023, 10:52 AM
 */


#include <xc.h>

void main(void) {
    return;
}
