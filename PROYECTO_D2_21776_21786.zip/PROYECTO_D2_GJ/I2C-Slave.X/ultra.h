#ifndef ULTRA_H
#define	ULTRA_H

#ifndef PinTRIG
#define PinTRIG TRISB0
#endif 

#ifndef PinECHO
#define PinECHO TRISB1
#endif 

#ifndef TRIGOut
#define TRIGOut RB0
#endif 

#ifndef ECHOIn
#define ECHOIn RB1
#endif 

#include <xc.h> 
#include <stdint.h>

void iniciar_sensor_ultrasonico(void);

float medir_distancia_ultrasonico(void);

#endif // ULTRA_H